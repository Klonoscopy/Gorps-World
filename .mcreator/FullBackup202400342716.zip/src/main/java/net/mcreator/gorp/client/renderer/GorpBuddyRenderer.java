
package net.mcreator.gorp.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.gorp.entity.GorpBuddyEntity;
import net.mcreator.gorp.client.model.Modelgorp_buddy;

import com.mojang.blaze3d.vertex.PoseStack;

public class GorpBuddyRenderer extends MobRenderer<GorpBuddyEntity, Modelgorp_buddy<GorpBuddyEntity>> {
	public GorpBuddyRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelgorp_buddy(context.bakeLayer(Modelgorp_buddy.LAYER_LOCATION)), 0.5f);
	}

	@Override
	protected void scale(GorpBuddyEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(1.2f, 1.2f, 1.2f);
	}

	@Override
	public ResourceLocation getTextureLocation(GorpBuddyEntity entity) {
		return new ResourceLocation("gorp:textures/entities/gorp_buddy.png");
	}
}
