package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.init.GorpModAttributes;

public class JorpkeyOnKeyReleasedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.onGround()) {
			if (entity instanceof LivingEntity _livingEntity1 && _livingEntity1.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()))
				_livingEntity1.getAttribute(GorpModAttributes.JORPS.get()).setBaseValue(0);
		} else if ((entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()) ? _livingEntity2.getAttribute(GorpModAttributes.JORPS.get()).getBaseValue() : 0) == 2) {
			if (entity instanceof LivingEntity _livingEntity3 && _livingEntity3.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()))
				_livingEntity3.getAttribute(GorpModAttributes.JORPS.get()).setBaseValue(2);
		} else {
			if (entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()))
				_livingEntity4.getAttribute(GorpModAttributes.JORPS.get()).setBaseValue(1);
		}
	}
}
