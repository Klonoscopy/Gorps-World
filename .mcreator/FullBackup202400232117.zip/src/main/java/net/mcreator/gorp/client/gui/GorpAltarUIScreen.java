package net.mcreator.gorp.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.gorp.world.inventory.GorpAltarUIMenu;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class GorpAltarUIScreen extends AbstractContainerScreen<GorpAltarUIMenu> {
	private final static HashMap<String, Object> guistate = GorpAltarUIMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;

	public GorpAltarUIScreen(GorpAltarUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = new ResourceLocation("gorp:textures/screens/gorp_altar_ui_empty.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_empty.label_gorp"), 8, 7, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_empty.label_this_altar_lacks_a_gorp_at_its_m"), 24, 63, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_empty.label_find_a_gorp_and_place_him_on_an"), 24, 71, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_empty.label_on_an_altar"), 24, 79, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
	}
}
