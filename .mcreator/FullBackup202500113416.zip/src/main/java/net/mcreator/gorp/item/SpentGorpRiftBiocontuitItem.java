
package net.mcreator.gorp.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SpentGorpRiftBiocontuitItem extends Item {
	public SpentGorpRiftBiocontuitItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
