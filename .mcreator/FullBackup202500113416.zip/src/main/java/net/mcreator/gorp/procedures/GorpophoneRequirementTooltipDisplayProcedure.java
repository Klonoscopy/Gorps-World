package net.mcreator.gorp.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.gorp.network.GorpModVariables;

public class GorpophoneRequirementTooltipDisplayProcedure {
	public static boolean execute(LevelAccessor world) {
		return !(GorpModVariables.MapVariables.get(world).gorpophone_slot_count >= 1);
	}
}
