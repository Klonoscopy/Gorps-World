package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.Entity;

public class MurdlerLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(80);
	}
}
