package net.mcreator.gorp.procedures;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.entity.HostileBreadEntity;

public class HostileBreadRightClickedOnEntityProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double peanutbutter = 0;
		if ((entity instanceof HostileBreadEntity _datEntL0 && _datEntL0.getEntityData().get(HostileBreadEntity.DATA_peanutbutter)) == false
				&& (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Items.GLOW_BERRIES && (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
			if (entity instanceof HostileBreadEntity _datEntSetL)
				_datEntSetL.getEntityData().set(HostileBreadEntity.DATA_peanutbutter, true);
			if (sourceentity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(Items.GLOW_BERRIES);
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) ((entity instanceof Player _plr ? _plr.getAbilities().instabuild : false) ? 0 : 1), _player.inventoryMenu.getCraftSlots());
			}
		}
	}
}
