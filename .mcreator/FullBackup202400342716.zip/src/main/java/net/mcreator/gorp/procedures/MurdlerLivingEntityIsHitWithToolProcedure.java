package net.mcreator.gorp.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.GorpMod;

public class MurdlerLivingEntityIsHitWithToolProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		entity.setSecondsOnFire(1);
		GorpMod.queueServerWork(3, () -> {
			entity.clearFire();
		});
	}
}
