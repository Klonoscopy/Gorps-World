package net.mcreator.gorp.procedures;

import net.minecraft.client.gui.components.EditBox;

import java.util.HashMap;

public class GorpAltarSendProcedure {
	public static void execute(HashMap guistate) {
		if (guistate == null)
			return;
		if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").equals("Hello")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Glub...");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").equals("Hi")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Gweb...");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").equals("poop")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Fuck off, freak.");
		}
	}
}
