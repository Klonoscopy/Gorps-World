package net.mcreator.gorp.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;

import net.mcreator.gorp.world.inventory.GorpAltarUIFullMenu;
import net.mcreator.gorp.network.GorpAltarUIFullButtonMessage;
import net.mcreator.gorp.GorpMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class GorpAltarUIFullScreen extends AbstractContainerScreen<GorpAltarUIFullMenu> {
	private final static HashMap<String, Object> guistate = GorpAltarUIFullMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	EditBox GorpMessage;
	EditBox GorpResponse;
	ImageButton imagebutton_gorp;

	public GorpAltarUIFullScreen(GorpAltarUIFullMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 276;
		this.imageHeight = 166;
	}

	private static final ResourceLocation texture = new ResourceLocation("gorp:textures/screens/gorp_altar_ui_full.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		GorpMessage.render(guiGraphics, mouseX, mouseY, partialTicks);
		GorpResponse.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);

		guiGraphics.blit(new ResourceLocation("gorp:textures/screens/gorp_bubble.png"), this.leftPos + 12, this.topPos + 111, 0, 0, 26, 20, 26, 20);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		if (GorpMessage.isFocused())
			return GorpMessage.keyPressed(key, b, c);
		if (GorpResponse.isFocused())
			return GorpResponse.keyPressed(key, b, c);
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
		GorpMessage.tick();
		GorpResponse.tick();
	}

	@Override
	public void resize(Minecraft minecraft, int width, int height) {
		String GorpMessageValue = GorpMessage.getValue();
		String GorpResponseValue = GorpResponse.getValue();
		super.resize(minecraft, width, height);
		GorpMessage.setValue(GorpMessageValue);
		GorpResponse.setValue(GorpResponseValue);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_gorp"), 10, 7, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_the_altar_allows_you_to_speak_wi"), 58, 30, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_with_gorp"), 58, 40, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_say_hello_to_gorp"), 58, 87, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_the_language_of_gorps_to_english"), 58, 50, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_channeled_energy_from_the_ground"), 57, 60, -12829636, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.gorp.gorp_altar_ui_full.label_ground"), 57, 70, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		GorpMessage = new EditBox(this.font, this.leftPos + 11, this.topPos + 139, 230, 18, Component.translatable("gui.gorp.gorp_altar_ui_full.GorpMessage")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.gorp.gorp_altar_ui_full.GorpMessage").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos) {
				super.moveCursorTo(pos);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.gorp.gorp_altar_ui_full.GorpMessage").getString());
				else
					setSuggestion(null);
			}
		};
		GorpMessage.setSuggestion(Component.translatable("gui.gorp.gorp_altar_ui_full.GorpMessage").getString());
		GorpMessage.setMaxLength(32767);
		guistate.put("text:GorpMessage", GorpMessage);
		this.addWidget(this.GorpMessage);
		GorpResponse = new EditBox(this.font, this.leftPos + 40, this.topPos + 115, 225, 18, Component.translatable("gui.gorp.gorp_altar_ui_full.GorpResponse")) {
			@Override
			public void insertText(String text) {
				super.insertText(text);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.gorp.gorp_altar_ui_full.GorpResponse").getString());
				else
					setSuggestion(null);
			}

			@Override
			public void moveCursorTo(int pos) {
				super.moveCursorTo(pos);
				if (getValue().isEmpty())
					setSuggestion(Component.translatable("gui.gorp.gorp_altar_ui_full.GorpResponse").getString());
				else
					setSuggestion(null);
			}
		};
		GorpResponse.setSuggestion(Component.translatable("gui.gorp.gorp_altar_ui_full.GorpResponse").getString());
		GorpResponse.setMaxLength(32767);
		guistate.put("text:GorpResponse", GorpResponse);
		this.addWidget(this.GorpResponse);
		imagebutton_gorp = new ImageButton(this.leftPos + 246, this.topPos + 139, 20, 18, 0, 0, 18, new ResourceLocation("gorp:textures/screens/atlas/imagebutton_gorp.png"), 20, 36, e -> {
			if (true) {
				GorpMod.PACKET_HANDLER.sendToServer(new GorpAltarUIFullButtonMessage(0, x, y, z));
				GorpAltarUIFullButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		});
		guistate.put("button:imagebutton_gorp", imagebutton_gorp);
		this.addRenderableWidget(imagebutton_gorp);
	}
}
