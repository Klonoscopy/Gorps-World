package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.init.GorpModItems;
import net.mcreator.gorp.init.GorpModEnchantments;

public class JorpingEffectStartedappliedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (EnchantmentHelper.getItemEnchantmentLevel(GorpModEnchantments.JORP.get(), (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			if (true) {
				entity.setDeltaMovement(new Vec3(0, (0.2 + (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getEnchantmentLevel(GorpModEnchantments.JORP.get()) / 10), 0));
			} else if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == GorpModItems.GORP_HAMMER.get()) {
				entity.setDeltaMovement(new Vec3(0, (0.3 + (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getEnchantmentLevel(GorpModEnchantments.JORP.get()) / 10), 0));
			}
		} else {
			entity.setDeltaMovement(new Vec3(0, 0.3, 0));
		}
	}
}
