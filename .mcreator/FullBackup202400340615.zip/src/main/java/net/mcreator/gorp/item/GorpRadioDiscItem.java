
package net.mcreator.gorp.item;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;

public class GorpRadioDiscItem extends RecordItem {
	public GorpRadioDiscItem() {
		super(5, () -> ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("gorp:gorp_radio")), new Item.Properties().stacksTo(1).rarity(Rarity.RARE), 3220);
	}
}
