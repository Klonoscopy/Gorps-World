package net.mcreator.gorp.procedures;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.Minecraft;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.mcreator.gorp.network.GorpModVariables;
import net.mcreator.gorp.init.GorpModItems;
import net.mcreator.gorp.init.GorpModBlocks;

import java.util.Random;
import java.util.HashMap;

public class GorpAltarSendProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		double Random = 0;
		GorpModVariables.MapVariables.get(world).gorp_talk = guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "";
		GorpModVariables.MapVariables.get(world).syncData(world);
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GorpModBlocks.GORP_ALTAR_FULL_S_PICY.get()) {
			if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("hello")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("YOU PISS ME OFF!!!!!");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("why")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("I HATE YOU!!!!!!");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("music")
					|| (guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("song")) {
				if (!(entity instanceof ServerPlayer _plr9 && _plr9.level() instanceof ServerLevel
						&& _plr9.getAdvancements().getOrStartProgress(_plr9.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:gorpinominal_taste"))).isDone())) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("TAKE THIS AND PISS OFF!!!");
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(GorpModItems.GORP_RADIO_DISC_DE.get()).copy();
						_setstack.setCount(1);
						ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
					}
					if (entity instanceof ServerPlayer _player) {
						Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:gorpinominal_taste"));
						AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
						if (!_ap.isDone()) {
							for (String criteria : _ap.getRemainingCriteria())
								_player.getAdvancements().award(_adv, criteria);
						}
					}
				} else {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("PISS OFF!!!!!!!!");
				}
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("gorpy layer")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("I DON'T CARE!!!!!!!!");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").length() > 0) {
				Random = Mth.nextInt(RandomSource.create(), 0, 4);
				if (Random == 0) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("GRRR...");
				} else if (Random == 1) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("WHO CARES...");
				} else if (Random == 2) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("DIE!!!");
				} else if (Random == 3) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("BIG WHOOP...");
				} else if (Random == 4) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("ARRGGHH!!");
				}
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GorpModBlocks.GORP_ALTAR_FULL_ICY.get()) {
			if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("hello")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("do you have a blanket I could borrow?");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("why")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("i'm a bit chilly, heh.");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("no")
					|| (guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("sorry")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("i'm so cold i am begging you please");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("gorpy layer")) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("i just really need a blanket right now");
			} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").length() > 0) {
				Random = Mth.nextInt(RandomSource.create(), 0, 4);
				if (Random == 0) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("brrr...");
				} else if (Random == 1) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("chitterchitter...");
				} else if (Random == 2) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("pardon?");
				} else if (Random == 3) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("freezes...");
				} else if (Random == 4) {
					if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
						_tf.setValue("huh?");
				}
			}
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("hello")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Hi! I'm Gorp!");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("hi")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Hello! I am Gorp!");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("i have a boner")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Rightly so!");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("whats up")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Just keep on Jorpin' on...");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("music")
				|| (guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("song")) {
			if (!(entity instanceof ServerPlayer _plr51 && _plr51.level() instanceof ServerLevel
					&& _plr51.getAdvancements().getOrStartProgress(_plr51.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:gorpinominal_taste"))).isDone())) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Hey, wanna listen to some tunes?");
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(GorpModItems.GORP_RADIO_DISC_PHLAB.get()).copy();
					_setstack.setCount(1);
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
				if (entity instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:gorpinominal_taste"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			} else {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("The Cyberpunk 2077 OST is the freaking bomb!");
			}
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("aggrussel")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("I hate those stinky aggrussels!");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("tron")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Tron Legacy is one of the all-time greats!");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("bite")
				|| (guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("permission")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("A watched pot never boils! ...or something");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("last ascension")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Just sayin', mage class is for losers");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("i love you")) {
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (world.isClientSide())
				Minecraft.getInstance().gameRenderer.displayItemActivation(new ItemStack(GorpModItems.AREA_EFFECT_CLOUD_2.get()));
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("how are you")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("I'm doing quite gorpily!");
		} else if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("let me eat your gorpy layer")) {
			if (entity instanceof ServerPlayer _plr71 && _plr71.level() instanceof ServerLevel && _plr71.getAdvancements().getOrStartProgress(_plr71.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:permission_gorped"))).isDone()) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("I already said you could! Bite away!");
			} else {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Okay! You asked nicely after all.");
				if (entity instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:permission_gorped"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase().contains("help")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("What do you need help with?");
		} else if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("/bypassgorp epic style")) {
			if (entity instanceof ServerPlayer _player) {
				Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:permission_gorped"));
				AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
				if (!_ap.isDone()) {
					for (String criteria : _ap.getRemainingCriteria())
						_player.getAdvancements().award(_adv, criteria);
				}
			}
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").length() > 0) {
			Random = Mth.nextInt(RandomSource.create(), 0, 4);
			if (Random == 0) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Gweb...");
			} else if (Random == 1) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Glubb...");
			} else if (Random == 2) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Gwib...");
			} else if (Random == 3) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Glululu...");
			} else if (Random == 4) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Glup...");
			}
		}
	}
}
