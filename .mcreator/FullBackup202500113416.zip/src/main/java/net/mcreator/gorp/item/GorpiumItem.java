
package net.mcreator.gorp.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GorpiumItem extends Item {
	public GorpiumItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
