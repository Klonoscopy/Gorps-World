
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.gorp.potion.JorpingMobEffect;
import net.mcreator.gorp.potion.IronHDamageMobEffect;
import net.mcreator.gorp.GorpMod;

public class GorpModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, GorpMod.MODID);
	public static final RegistryObject<MobEffect> JORPING = REGISTRY.register("jorping", () -> new JorpingMobEffect());
	public static final RegistryObject<MobEffect> IRON_H_DAMAGE = REGISTRY.register("iron_h_damage", () -> new IronHDamageMobEffect());
}
