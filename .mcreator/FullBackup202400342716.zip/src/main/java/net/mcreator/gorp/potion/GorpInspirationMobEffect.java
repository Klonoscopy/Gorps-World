
package net.mcreator.gorp.potion;

import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.gorp.procedures.GorpShirtTickEventProcedure;
import net.mcreator.gorp.procedures.GorpInspirationEffectStartedappliedProcedure;
import net.mcreator.gorp.procedures.GorpInspirationEffectExpiresProcedure;

public class GorpInspirationMobEffect extends MobEffect {
	public GorpInspirationMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -3342490);
	}

	@Override
	public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		GorpInspirationEffectStartedappliedProcedure.execute(entity);
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		GorpShirtTickEventProcedure.execute(entity);
	}

	@Override
	public void removeAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
		super.removeAttributeModifiers(entity, attributeMap, amplifier);
		GorpInspirationEffectExpiresProcedure.execute(entity);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
