
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.EntityType;

import net.mcreator.gorp.GorpMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class GorpModAttributes {
	public static final DeferredRegister<Attribute> REGISTRY = DeferredRegister.create(ForgeRegistries.ATTRIBUTES, GorpMod.MODID);
	public static final RegistryObject<Attribute> JORPS = REGISTRY.register("jorps", () -> new RangedAttribute("attribute.gorp.jorps", 0, 0, 1).setSyncable(true));
	public static final RegistryObject<Attribute> JORPABLE = REGISTRY.register("jorpable", () -> new RangedAttribute("attribute.gorp.jorpable", 0, 0, 1).setSyncable(true));

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		event.add(EntityType.PLAYER, JORPS.get());
		event.add(EntityType.PLAYER, JORPABLE.get());
	}

	@Mod.EventBusSubscriber
	public static class PlayerAttributesSync {
		@SubscribeEvent
		public static void playerClone(PlayerEvent.Clone event) {
			Player oldPlayer = event.getOriginal();
			Player newPlayer = event.getEntity();
			newPlayer.getAttribute(JORPS.get()).setBaseValue(oldPlayer.getAttribute(JORPS.get()).getBaseValue());
			newPlayer.getAttribute(JORPABLE.get()).setBaseValue(oldPlayer.getAttribute(JORPABLE.get()).getBaseValue());
		}
	}
}
