package net.mcreator.gorp.procedures;

public class LoreBookProcedure {
	public static void execute() {
	}
}
