package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.init.GorpModAttributes;

public class GorpShirtTickEventProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livingEntity0 && _livingEntity0.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()) ? _livingEntity0.getAttribute(GorpModAttributes.JORPS.get()).getBaseValue() : 0) != 0) {
			if (entity.onGround()) {
				if (entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()))
					_livingEntity2.getAttribute(GorpModAttributes.JORPS.get()).setBaseValue(0);
			}
		}
	}
}
