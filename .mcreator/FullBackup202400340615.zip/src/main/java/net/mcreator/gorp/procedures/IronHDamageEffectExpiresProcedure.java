package net.mcreator.gorp.procedures;

public class IronHDamageEffectExpiresProcedure {
	public static void execute() {
	}
}
