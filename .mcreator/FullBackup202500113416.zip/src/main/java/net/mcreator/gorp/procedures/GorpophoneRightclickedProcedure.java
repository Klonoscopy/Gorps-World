package net.mcreator.gorp.procedures;

public class GorpophoneRightclickedProcedure {
	public static void execute() {
	}
}
