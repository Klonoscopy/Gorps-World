
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.gorp.item.SpicyGorpItem;
import net.mcreator.gorp.item.RoastedGorpSeedItem;
import net.mcreator.gorp.item.MurdlerItem;
import net.mcreator.gorp.item.IcyGorpItem;
import net.mcreator.gorp.item.GorpophoneItem;
import net.mcreator.gorp.item.GorpeenItem;
import net.mcreator.gorp.item.GorpStaffItem;
import net.mcreator.gorp.item.GorpSpearItem;
import net.mcreator.gorp.item.GorpShirtItem;
import net.mcreator.gorp.item.GorpRadioDiscItem;
import net.mcreator.gorp.item.GorpJuiceItem;
import net.mcreator.gorp.item.GorpItem;
import net.mcreator.gorp.item.GorpHammerItem;
import net.mcreator.gorp.item.GorpFabricItem;
import net.mcreator.gorp.item.DiceyGorpItem;
import net.mcreator.gorp.item.DangerousEnvironmentsDiscItem;
import net.mcreator.gorp.item.ConsolidatedGorpCubeItem;
import net.mcreator.gorp.item.BittenGorpItem;
import net.mcreator.gorp.GorpMod;

public class GorpModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, GorpMod.MODID);
	public static final RegistryObject<Item> GORP = REGISTRY.register("gorp", () -> new GorpItem());
	public static final RegistryObject<Item> BITTEN_GORP = REGISTRY.register("bitten_gorp", () -> new BittenGorpItem());
	public static final RegistryObject<Item> GORP_SEED = block(GorpModBlocks.GORP_SEED);
	public static final RegistryObject<Item> GORP_PLANT_STAGE_1 = block(GorpModBlocks.GORP_PLANT_STAGE_1);
	public static final RegistryObject<Item> GORP_PLANT_STAGE_2 = block(GorpModBlocks.GORP_PLANT_STAGE_2);
	public static final RegistryObject<Item> GORP_PLANT_STAGE_3 = block(GorpModBlocks.GORP_PLANT_STAGE_3);
	public static final RegistryObject<Item> GORP_SPROUT = block(GorpModBlocks.GORP_SPROUT);
	public static final RegistryObject<Item> GORP_HAMMER = REGISTRY.register("gorp_hammer", () -> new GorpHammerItem());
	public static final RegistryObject<Item> GORP_STAFF = REGISTRY.register("gorp_staff", () -> new GorpStaffItem());
	public static final RegistryObject<Item> GORP_RADIO_DISC_PHLAB = REGISTRY.register("gorp_radio_disc_phlab", () -> new GorpRadioDiscItem());
	public static final RegistryObject<Item> JORP_JUICE = REGISTRY.register("jorp_juice", () -> new GorpJuiceItem());
	public static final RegistryObject<Item> GORP_RADIO_DISC_DE = REGISTRY.register("gorp_radio_disc_de", () -> new DangerousEnvironmentsDiscItem());
	public static final RegistryObject<Item> GORP_ALTAR = block(GorpModBlocks.GORP_ALTAR);
	public static final RegistryObject<Item> GORP_ALTAR_FULL = block(GorpModBlocks.GORP_ALTAR_FULL);
	public static final RegistryObject<Item> GORP_SPEAR = REGISTRY.register("gorp_spear", () -> new GorpSpearItem());
	public static final RegistryObject<Item> GORP_MERCH_HELMET = REGISTRY.register("gorp_merch_helmet", () -> new GorpShirtItem.Helmet());
	public static final RegistryObject<Item> GORP_MERCH_CHESTPLATE = REGISTRY.register("gorp_merch_chestplate", () -> new GorpShirtItem.Chestplate());
	public static final RegistryObject<Item> GORP_MERCH_LEGGINGS = REGISTRY.register("gorp_merch_leggings", () -> new GorpShirtItem.Leggings());
	public static final RegistryObject<Item> GORP_MERCH_BOOTS = REGISTRY.register("gorp_merch_boots", () -> new GorpShirtItem.Boots());
	public static final RegistryObject<Item> GORP_FABRIC = REGISTRY.register("gorp_fabric", () -> new GorpFabricItem());
	public static final RegistryObject<Item> CONSOLIDATED_GORP_CUBE = REGISTRY.register("consolidated_gorp_cube", () -> new ConsolidatedGorpCubeItem());
	public static final RegistryObject<Item> AREA_EFFECT_CLOUD_2 = REGISTRY.register("area_effect_cloud_2", () -> new GorpeenItem());
	public static final RegistryObject<Item> ROASTED_GORP_SEED = REGISTRY.register("roasted_gorp_seed", () -> new RoastedGorpSeedItem());
	public static final RegistryObject<Item> GORP_BUDDY_SPAWN_EGG = REGISTRY.register("gorp_buddy_spawn_egg", () -> new ForgeSpawnEggItem(GorpModEntities.GORP_BUDDY, -6697984, -6711040, new Item.Properties()));
	public static final RegistryObject<Item> NETHER_GORP_SPROUT = block(GorpModBlocks.NETHER_GORP_SPROUT);
	public static final RegistryObject<Item> SPICY_GORP = REGISTRY.register("spicy_gorp", () -> new SpicyGorpItem());
	public static final RegistryObject<Item> ICY_GORP = REGISTRY.register("icy_gorp", () -> new IcyGorpItem());
	public static final RegistryObject<Item> DICEY_GORP = REGISTRY.register("dicey_gorp", () -> new DiceyGorpItem());
	public static final RegistryObject<Item> ICY_GORP_SPROUT = block(GorpModBlocks.ICY_GORP_SPROUT);
	public static final RegistryObject<Item> GORP_ALTAR_FULL_S_PICY = block(GorpModBlocks.GORP_ALTAR_FULL_S_PICY);
	public static final RegistryObject<Item> GORP_ALTAR_FULL_ICY = block(GorpModBlocks.GORP_ALTAR_FULL_ICY);
	public static final RegistryObject<Item> GORPOPHONE = REGISTRY.register("gorpophone", () -> new GorpophoneItem());
	public static final RegistryObject<Item> MURDLER = REGISTRY.register("murdler", () -> new MurdlerItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
