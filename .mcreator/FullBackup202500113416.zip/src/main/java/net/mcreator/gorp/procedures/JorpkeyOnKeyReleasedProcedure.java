package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.network.GorpModVariables;

public class JorpkeyOnKeyReleasedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.onGround()) {
			{
				double _setval = 0;
				entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.let_jorp = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		} else if ((entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).let_jorp == 2) {
			{
				double _setval = 2;
				entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.let_jorp = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		} else {
			{
				double _setval = 1;
				entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.let_jorp = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
