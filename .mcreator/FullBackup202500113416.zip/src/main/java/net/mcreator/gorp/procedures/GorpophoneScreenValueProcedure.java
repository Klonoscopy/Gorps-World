package net.mcreator.gorp.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;

import java.util.function.Supplier;
import java.util.Map;
import java.util.HashMap;

public class GorpophoneScreenValueProcedure {
	public static String execute(Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return "";
		String txt = "";
		if ((guistate.containsKey("text:gorpcastmsg") ? ((EditBox) guistate.get("text:gorpcastmsg")).getValue() : "").isEmpty() && new Object() {
			public int getAmount(int sltid) {
				if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
					ItemStack stack = ((Slot) _slots.get(sltid)).getItem();
					if (stack != null)
						return stack.getCount();
				}
				return 0;
			}
		}.getAmount(0) >= (guistate.containsKey("checkbox:anon_gorpcast") && ((Checkbox) guistate.get("checkbox:anon_gorpcast")).selected() ? 2 : 1)) {
			txt = "Text field cannot be empty";
		} else if (guistate.containsKey("checkbox:anon_gorpcast") && ((Checkbox) guistate.get("checkbox:anon_gorpcast")).selected()) {
			txt = "\u00A7cRequires (2x) Gorp Coin";
		} else if (!(guistate.containsKey("checkbox:anon_gorpcast") && ((Checkbox) guistate.get("checkbox:anon_gorpcast")).selected())) {
			txt = "\u00A7cRequires (1x) Gorp Coin";
		} else {
			txt = "";
		}
		return txt;
	}
}
