package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.init.GorpModAttributes;

public class GorpInspirationEffectExpiresProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livingEntity0 && _livingEntity0.getAttributes().hasAttribute(GorpModAttributes.JORPABLE.get()))
			_livingEntity0.getAttribute(GorpModAttributes.JORPABLE.get()).setBaseValue(0);
	}
}
