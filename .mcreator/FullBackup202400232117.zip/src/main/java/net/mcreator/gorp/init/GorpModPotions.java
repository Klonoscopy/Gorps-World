
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.gorp.GorpMod;

public class GorpModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(ForgeRegistries.POTIONS, GorpMod.MODID);
	public static final RegistryObject<Potion> POTION_OF_JORPING = REGISTRY.register("potion_of_jorping", () -> new Potion(new MobEffectInstance(GorpModMobEffects.JORPING.get(), 3, 0, false, true)));
}
