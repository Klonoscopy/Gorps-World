package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.init.GorpModEnchantments;

import java.util.List;
import java.util.Comparator;

public class GorpSpearOnPlayerStoppedUsingProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		double Knockback = 0;
		if (EnchantmentHelper.getItemEnchantmentLevel(GorpModEnchantments.FLINGING.get(), itemstack) != 0) {
			Knockback = Math.min(entity instanceof LivingEntity _entUseTicks2 ? _entUseTicks2.getTicksUsingItem() : 0, 20) * 0.1 * 3 + itemstack.getEnchantmentLevel(GorpModEnchantments.FLINGING.get());
		} else {
			Knockback = Math.min(entity instanceof LivingEntity _entUseTicks5 ? _entUseTicks5.getTicksUsingItem() : 0, 20) * 0.1 * 3;
		}
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(2 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (Entity entityiterator : _entfound) {
				if (entityiterator instanceof Player) {
					entityiterator.setDeltaMovement(new Vec3((entity.getDeltaMovement().x() + Math.sin(entityiterator.getYRot() * (-1) * 0.017453292) * Math.cos(entityiterator.getXRot() * 0.017453292) * Knockback),
							(entity.getDeltaMovement().y() + Math.sin(entityiterator.getXRot() * 0.017453292) * (-1) * (Knockback / 1.5)),
							(entity.getDeltaMovement().z() + Math.cos(entityiterator.getYRot() * (-1) * 0.017453292) * Math.cos(entityiterator.getXRot() * 0.017453292) * Knockback)));
				}
			}
		}
		if (entity instanceof Player _player)
			_player.getCooldowns().addCooldown(itemstack.getItem(), (int) ((entity instanceof LivingEntity _entUseTicks17 ? _entUseTicks17.getTicksUsingItem() : 0) + 20));
	}
}
