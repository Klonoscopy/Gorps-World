package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

public class LoreBookProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof ServerPlayer _plr0 && _plr0.level() instanceof ServerLevel && _plr0.getAdvancements().getOrStartProgress(_plr0.server.getAdvancements().getAdvancement(new ResourceLocation("minecraft:story/root"))).isDone())) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"/give @p written_book{pages:['{\"text\":\"In the rolling hills of the Gorpiculon System, there lives a peculiar creature known only as Gorp. Small, green, and undeniably cute, Gorp appears to be nothing more than a sentient lump of nourishment. His soft, squishy body glows with a faint green hue, and his rounded shape gives him an\"}','{\"text\":\"appearance that is as friendly as he is delectable. However, beneath his charming exterior lies a being of immense magical power. Born from the life-giving energies of the earth, Gorp is a guardian spirit tasked with balancing nature\\'s greed and hunger Legend says that he was created\"}','{\"text\":\"by an ancient druid who sought to feed the starving to maintain harmony with the world around her. Despite being edible, Gorp is no mere snack. Those who consume a piece of him are imbued with vitality, enhanced abilities, and a connection to the natural world. \"}','{\"text\":\"However, the act of eating Gorp is not without its consequences. Doing so without his permission is said to anger the land, leading to misfortune and spoiled harvests. Gorp communicates through a series of soft, gooey sounds, and while he lacks complex speech,\"}','{\"text\":\"he conveys his emotions and intent in his expressions. Still, only the most attuned individuals can truly understand the depths of Gorp\\'s wisdom, as he serves as both a protector of nature and a reminder of the delicate balance between consumption and conservation.\"}'],title:\"Secrets of the Gorp\",author:Unknown,generation:3}");
		}
	}
}
