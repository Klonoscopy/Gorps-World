
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.gorp.world.inventory.GorpcastGUIMenu;
import net.mcreator.gorp.world.inventory.GorpBuddyGuiMenu;
import net.mcreator.gorp.world.inventory.GorpAltarUIFullMenu;
import net.mcreator.gorp.GorpMod;

public class GorpModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, GorpMod.MODID);
	public static final RegistryObject<MenuType<GorpAltarUIFullMenu>> GORP_ALTAR_UI_FULL = REGISTRY.register("gorp_altar_ui_full", () -> IForgeMenuType.create(GorpAltarUIFullMenu::new));
	public static final RegistryObject<MenuType<GorpBuddyGuiMenu>> GORP_BUDDY_GUI = REGISTRY.register("gorp_buddy_gui", () -> IForgeMenuType.create(GorpBuddyGuiMenu::new));
	public static final RegistryObject<MenuType<GorpcastGUIMenu>> GORPCAST_GUI = REGISTRY.register("gorpcast_gui", () -> IForgeMenuType.create(GorpcastGUIMenu::new));
}
