
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.gorp.item.GorpStaffItem;
import net.mcreator.gorp.item.GorpRadioDiscItem;
import net.mcreator.gorp.item.GorpJuiceItem;
import net.mcreator.gorp.item.GorpItem;
import net.mcreator.gorp.item.GorpHammerItem;
import net.mcreator.gorp.item.DangerousEnvironmentsDiscItem;
import net.mcreator.gorp.item.BittenGorpItem;
import net.mcreator.gorp.GorpMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class GorpModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, GorpMod.MODID);
	public static final RegistryObject<Item> GORP = REGISTRY.register("gorp", () -> new GorpItem());
	public static final RegistryObject<Item> BITTEN_GORP = REGISTRY.register("bitten_gorp", () -> new BittenGorpItem());
	public static final RegistryObject<Item> GORP_SEED = block(GorpModBlocks.GORP_SEED);
	public static final RegistryObject<Item> GORP_PLANT_STAGE_1 = block(GorpModBlocks.GORP_PLANT_STAGE_1);
	public static final RegistryObject<Item> GORP_PLANT_STAGE_2 = block(GorpModBlocks.GORP_PLANT_STAGE_2);
	public static final RegistryObject<Item> GORP_PLANT_STAGE_3 = block(GorpModBlocks.GORP_PLANT_STAGE_3);
	public static final RegistryObject<Item> GORP_SPROUT = block(GorpModBlocks.GORP_SPROUT);
	public static final RegistryObject<Item> GORP_HAMMER = REGISTRY.register("gorp_hammer", () -> new GorpHammerItem());
	public static final RegistryObject<Item> GORP_STAFF = REGISTRY.register("gorp_staff", () -> new GorpStaffItem());
	public static final RegistryObject<Item> GORP_RADIO_DISC_PHLAB = REGISTRY.register("gorp_radio_disc_phlab", () -> new GorpRadioDiscItem());
	public static final RegistryObject<Item> JORP_JUICE = REGISTRY.register("jorp_juice", () -> new GorpJuiceItem());
	public static final RegistryObject<Item> GORP_RADIO_DISC_DE = REGISTRY.register("gorp_radio_disc_de", () -> new DangerousEnvironmentsDiscItem());
	public static final RegistryObject<Item> GORP_ALTAR = block(GorpModBlocks.GORP_ALTAR);
	public static final RegistryObject<Item> GORP_ALTAR_FULL = block(GorpModBlocks.GORP_ALTAR_FULL);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(GORP_STAFF.get(), new ResourceLocation("blocking"), ItemProperties.getProperty(Items.SHIELD, new ResourceLocation("blocking")));
		});
	}
}
