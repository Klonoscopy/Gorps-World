
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.gorp.block.NetherGorpSproutBlock;
import net.mcreator.gorp.block.IcyGorpSproutBlock;
import net.mcreator.gorp.block.GorpSproutBlock;
import net.mcreator.gorp.block.GorpPlantStage3Block;
import net.mcreator.gorp.block.GorpPlantStage2Block;
import net.mcreator.gorp.block.GorpPlantStage1Block;
import net.mcreator.gorp.block.GorpPlantStage0Block;
import net.mcreator.gorp.block.GorpAltarFullSPicyBlock;
import net.mcreator.gorp.block.GorpAltarFullIcyBlock;
import net.mcreator.gorp.block.GorpAltarFullBlock;
import net.mcreator.gorp.block.GorpAltarBlock;
import net.mcreator.gorp.GorpMod;

public class GorpModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, GorpMod.MODID);
	public static final RegistryObject<Block> GORP_SEED = REGISTRY.register("gorp_seed", () -> new GorpPlantStage0Block());
	public static final RegistryObject<Block> GORP_PLANT_STAGE_1 = REGISTRY.register("gorp_plant_stage_1", () -> new GorpPlantStage1Block());
	public static final RegistryObject<Block> GORP_PLANT_STAGE_2 = REGISTRY.register("gorp_plant_stage_2", () -> new GorpPlantStage2Block());
	public static final RegistryObject<Block> GORP_PLANT_STAGE_3 = REGISTRY.register("gorp_plant_stage_3", () -> new GorpPlantStage3Block());
	public static final RegistryObject<Block> GORP_SPROUT = REGISTRY.register("gorp_sprout", () -> new GorpSproutBlock());
	public static final RegistryObject<Block> GORP_ALTAR = REGISTRY.register("gorp_altar", () -> new GorpAltarBlock());
	public static final RegistryObject<Block> GORP_ALTAR_FULL = REGISTRY.register("gorp_altar_full", () -> new GorpAltarFullBlock());
	public static final RegistryObject<Block> NETHER_GORP_SPROUT = REGISTRY.register("nether_gorp_sprout", () -> new NetherGorpSproutBlock());
	public static final RegistryObject<Block> ICY_GORP_SPROUT = REGISTRY.register("icy_gorp_sprout", () -> new IcyGorpSproutBlock());
	public static final RegistryObject<Block> GORP_ALTAR_FULL_S_PICY = REGISTRY.register("gorp_altar_full_s_picy", () -> new GorpAltarFullSPicyBlock());
	public static final RegistryObject<Block> GORP_ALTAR_FULL_ICY = REGISTRY.register("gorp_altar_full_icy", () -> new GorpAltarFullIcyBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
