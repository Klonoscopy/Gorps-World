
package net.mcreator.gorp.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

import net.mcreator.gorp.procedures.SoundChompProcedure;
import net.mcreator.gorp.procedures.GorpStaffRightclickedProcedure;

public class GorpStaffItem extends ShieldItem {
	public GorpStaffItem() {
		super(new Item.Properties().durability(59));
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		GorpStaffRightclickedProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ(), entity, ar.getObject());
		return ar;
	}

	@Override
	public void onCraftedBy(ItemStack itemstack, Level world, Player entity) {
		super.onCraftedBy(itemstack, world, entity);
		SoundChompProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ());
	}
}
