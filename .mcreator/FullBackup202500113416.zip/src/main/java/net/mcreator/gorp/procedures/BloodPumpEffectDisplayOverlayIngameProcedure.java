package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.network.GorpModVariables;

public class BloodPumpEffectDisplayOverlayIngameProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double timescale = 0;
		if ((entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).OutOfCombatCooldown == 0) {
			timescale = 0.05;
		} else {
			timescale = 0.025;
		}
		{
			double _setval = Math.max((entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).BloodPumpOverlayFade - timescale, 0);
			entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.BloodPumpOverlayFade = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}
