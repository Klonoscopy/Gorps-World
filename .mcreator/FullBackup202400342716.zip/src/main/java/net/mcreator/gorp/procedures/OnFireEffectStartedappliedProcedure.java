package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.Entity;

public class OnFireEffectStartedappliedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.setMaxUpStep((float) (entity.getStepHeight() + 0.6));
	}
}
