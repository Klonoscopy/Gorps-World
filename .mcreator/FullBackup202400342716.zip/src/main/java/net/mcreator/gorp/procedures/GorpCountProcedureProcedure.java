package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import net.mcreator.gorp.network.GorpModVariables;

public class GorpCountProcedureProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal(("Gorps: " + (entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).gorp_count + ", Bitten Gorps: "
					+ (entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).bitten_gorp_count)), true);
	}
}
