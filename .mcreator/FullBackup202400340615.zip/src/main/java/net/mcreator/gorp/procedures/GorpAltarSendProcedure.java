package net.mcreator.gorp.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import java.util.Random;
import java.util.HashMap;

public class GorpAltarSendProcedure {
	public static void execute(Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		double Random = 0;
		if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("hello")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Hi! I'm Gorp!");
		} else if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("hi")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("Hello! I am Gorp!");
		} else if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("how are you")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("I'm doing quite gorpily!");
		} else if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("let me eat your gorpy layer")) {
			if (entity instanceof ServerPlayer _plr7 && _plr7.level() instanceof ServerLevel && _plr7.getAdvancements().getOrStartProgress(_plr7.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:permission_gorped"))).isDone()) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("I already said you could!");
			} else {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Okay! You asked nicely after all.");
				if (entity instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:permission_gorped"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		} else if (((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").toLowerCase()).equals("i need your help")) {
			if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
				_tf.setValue("What seems to be the problem?");
		} else if ((guistate.containsKey("text:GorpMessage") ? ((EditBox) guistate.get("text:GorpMessage")).getValue() : "").length() > 0) {
			Random = Mth.nextInt(RandomSource.create(), 0, 4);
			if (Random == 0) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Gweb...");
			} else if (Random == 1) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Glubb...");
			} else if (Random == 2) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Gwib...");
			} else if (Random == 3) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Glululu...");
			} else if (Random == 4) {
				if (guistate.get("text:GorpResponse") instanceof EditBox _tf)
					_tf.setValue("Glup...");
			}
		}
	}
}
