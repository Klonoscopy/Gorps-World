package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.mcreator.gorp.network.GorpModVariables;

public class GorpPlayerFinishesUsingItemProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).gorp_count + 1;
			entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.gorp_count = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if ((entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).bitten_gorp_count == 100
				&& (entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new GorpModVariables.PlayerVariables())).gorp_count == 100) {
			if (entity instanceof ServerPlayer _player) {
				Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("gorp:gorpivore"));
				AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
				if (!_ap.isDone()) {
					for (String criteria : _ap.getRemainingCriteria())
						_player.getAdvancements().award(_adv, criteria);
				}
			}
		}
		SoundGulpProcedure.execute(world, x, y, z);
		entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x() * 1.5), (entity.getDeltaMovement().y() + 0.35), (entity.getDeltaMovement().z() * 1.5)));
		for (int index0 = 0; index0 < 3; index0++) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.SNEEZE, x, y, z, 4, 2, 2, 2, 1);
		}
		if (entity instanceof Player _player)
			_player.getCooldowns().addCooldown(itemstack.getItem(), 10);
	}
}
