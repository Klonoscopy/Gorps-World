
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.gorp.GorpMod;

public class GorpModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, GorpMod.MODID);
	public static final RegistryObject<SoundEvent> GULP = REGISTRY.register("gulp", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("gorp", "gulp")));
	public static final RegistryObject<SoundEvent> BELCH = REGISTRY.register("belch", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("gorp", "belch")));
	public static final RegistryObject<SoundEvent> CHOMP = REGISTRY.register("chomp", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("gorp", "chomp")));
	public static final RegistryObject<SoundEvent> GORP_RADIO = REGISTRY.register("gorp_radio", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("gorp", "gorp_radio")));
	public static final RegistryObject<SoundEvent> GORP_RADIO_DANGEROUS_ENVIRONMENTS = REGISTRY.register("gorp_radio_dangerous_environments",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("gorp", "gorp_radio_dangerous_environments")));
}
