package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;

import net.mcreator.gorp.init.GorpModItems;
import net.mcreator.gorp.init.GorpModAttributes;

public class JorpkeyOnKeyPressedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double jumps = 0;
		if ((entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY).getItem() == GorpModItems.GORP_MERCH_LEGGINGS.get()
				|| (entity instanceof LivingEntity _livingEntity2 && _livingEntity2.getAttributes().hasAttribute(GorpModAttributes.JORPABLE.get()) ? _livingEntity2.getAttribute(GorpModAttributes.JORPABLE.get()).getBaseValue() : 0) == 1) {
			if ((entity instanceof LivingEntity _livingEntity3 && _livingEntity3.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()) ? _livingEntity3.getAttribute(GorpModAttributes.JORPS.get()).getBaseValue() : 0) != 2) {
				if (entity.getDeltaMovement().y() != 0) {
					entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x() * 1.2), (entity.getDeltaMovement().y() + 0.4), (entity.getDeltaMovement().z() * 1.2)));
					if (entity instanceof LivingEntity _livingEntity10 && _livingEntity10.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()))
						_livingEntity10.getAttribute(GorpModAttributes.JORPS.get()).setBaseValue(
								((entity instanceof LivingEntity _livingEntity9 && _livingEntity9.getAttributes().hasAttribute(GorpModAttributes.JORPS.get()) ? _livingEntity9.getAttribute(GorpModAttributes.JORPS.get()).getBaseValue() : 0) + 1));
				}
			}
		}
	}
}
