package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

public class GorpBuddyOnEntityTickUpdateProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double timer = 0;
		timer = timer + 1;
		if (timer == 0) {
			if (entity.getDeltaMovement().x() != 0 || entity.getDeltaMovement().z() != 0) {
				entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), (entity.getDeltaMovement().y() + 1), (entity.getDeltaMovement().z())));
			}
		} else if (timer == 21) {
			timer = 0;
		}
		entity.setCustomName(Component.literal(("" + timer)));
	}
}
