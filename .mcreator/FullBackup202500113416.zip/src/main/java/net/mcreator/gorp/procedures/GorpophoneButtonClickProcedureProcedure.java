package net.mcreator.gorp.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Checkbox;

import net.mcreator.gorp.network.GorpModVariables;

import java.util.function.Supplier;
import java.util.Map;
import java.util.HashMap;

public class GorpophoneButtonClickProcedureProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		if (new Object() {
			public int getAmount(int sltid) {
				if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
					ItemStack stack = ((Slot) _slots.get(sltid)).getItem();
					if (stack != null)
						return stack.getCount();
				}
				return 0;
			}
		}.getAmount(0) > (guistate.containsKey("checkbox:anon_gorpcast") && ((Checkbox) guistate.get("checkbox:anon_gorpcast")).selected() ? 1 : 0)) {
			if (!(guistate.containsKey("text:gorpcastmsg") ? ((EditBox) guistate.get("text:gorpcastmsg")).getValue() : "").isEmpty()) {
				if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
					((Slot) _slots.get(0)).remove(1);
					_player.containerMenu.broadcastChanges();
				}
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"title @a times 8 50 8");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							("title @a subtitle {\"text\":\"\\\"" + "" + (guistate.containsKey("text:gorpcastmsg") ? ((EditBox) guistate.get("text:gorpcastmsg")).getValue() : "").replaceAll("\\\"", "") + "\\\"\"}"));
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"title @a title {\"text\":\"\"}");
				if (entity instanceof Player _player && !_player.level().isClientSide())
					_player.displayClientMessage(
							Component.literal(("Gorpcasted by: " + (guistate.containsKey("checkbox:anon_gorpcast") && ((Checkbox) guistate.get("checkbox:anon_gorpcast")).selected() ? "(user hidden)" : entity.getDisplayName().getString()))), true);
				if (entity instanceof Player _player)
					_player.closeContainer();
			}
			{
				boolean _setval = guistate.containsKey("checkbox:anon_gorpcast") && ((Checkbox) guistate.get("checkbox:anon_gorpcast")).selected();
				entity.getCapability(GorpModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.anon_cookie = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
