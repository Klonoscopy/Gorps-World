
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gorp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.gorp.GorpMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class GorpModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, GorpMod.MODID);
	public static final RegistryObject<CreativeModeTab> GORP_CREATIVE_TAB = REGISTRY.register("gorp_creative_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.gorp.gorp_creative_tab")).icon(() -> new ItemStack(GorpModItems.GORP.get())).displayItems((parameters, tabData) -> {
				tabData.accept(GorpModItems.GORP.get());
				tabData.accept(GorpModItems.BITTEN_GORP.get());
				tabData.accept(GorpModBlocks.GORP_SEED.get().asItem());
				tabData.accept(GorpModBlocks.GORP_PLANT_STAGE_3.get().asItem());
				tabData.accept(GorpModItems.GORP_HAMMER.get());
				tabData.accept(GorpModItems.GORP_STAFF.get());
				tabData.accept(GorpModItems.JORP_JUICE.get());
				tabData.accept(GorpModBlocks.GORP_ALTAR.get().asItem());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(GorpModBlocks.GORP_SPROUT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(GorpModItems.GORP_RADIO_DISC_PHLAB.get());
			tabData.accept(GorpModItems.GORP_RADIO_DISC_DE.get());
		}
	}
}
